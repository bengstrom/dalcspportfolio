import matplotlib.pyplot as plt #Needed for plot and labels
import os.path #Needed to get file
import csv #Needed to process CSV file
import numpy as np #Needed to generate random line color

def is_num(s):
    '''Checks if "s" is a numerical value.
    '''
    try:
        float(s)
        return True
    except ValueError:
        return False
        
def by_income(s):
    '''Returns true if "s" matches a  country code listed.
    '''
    # Set  maximum length of legend labels
    global words 
    words = 3
    
    try:
        if (s=="40044"          #High Income Population
            or s=="40043"       #Upper Middle Income Population
            or s=="40042"       #Lower Middle Income Population
            or s=="40041"       #Low Income Population
            or s =="40510"):    #World Average
            return True
        else:
            return False
    except ValueError:
        return False

def by_region(s):
    '''Returns true if "s" matches a  country code listed.
    '''
    # Set  maximum length of legend labels
    global words
    words = 2
    
    try:
        if (s=="40369"       #North America
            or s=="40370"       #South America
            or s=="40373"       #Oceana
            or s=="40371"       #Asia
            or s=="40370"       #Europe
            or s=="40368"       #Africa
            or s =="40510"):    #World Average
            return True
        else:
            return False
    except ValueError:
        return False

def by_status(s):
    '''Returns true if "s" matches a  country code listed.
    '''
    # Set  maximum length of legend labels
    global words
    words = 3
    
    try:
        if (s=="40387"       #Countries in Transition
            or s=="40388"       #Developed Countries
            or s=="40389"       #Developing Countries
            or s =="40510"):    #World Average
            return True
        else:
            return False
    except ValueError:
        return False

# Get the directory name for data files
directory = os.path.dirname(os.path.abspath(__file__))

# Open the file
filename = os.path.join(directory, 'female_education.csv')
mycsv = csv.reader(open(filename,'r'))   

# Create dictionary to correlate countrycode to country name
legend = {}

# Create list to hold rest of data
data = []
words = 2

# Process each row of the csv file
for row in mycsv:
    #Get wanted values from each row
    countrycode =  row[2]
    country = row[3] 
    year = row[5] 
    enrollment = row[6]
    
    # If countrycode matches selected function and data is from FEP_8
    # and percent enrolled is available then record data
    if (row[0]=="FEP_8") and is_num(row[6]) and by_status(row[2]):
#    if (row[0]=="FEP_8") and by_region(row[2]) and is_num(row[6]):
#    if (row[0]=="FEP_8") and by_income(row[2]) and is_num(row[6]):
        try:
            # If countrycode has not been added to dictionary, add it
            # then record countrycode and enrollment information to data list
            if countrycode not in legend:
                legend[countrycode] = country
                data.append([countrycode, (year,enrollment)])
            
            # If countrycode already in dictionary
            else:
                # Find row that matches countrycode and append new data to the end
                for i, c in enumerate(data):
                    try:
                        c.index(countrycode)
                        data[i].append((year,enrollment))
                    except ValueError:
                        continue
        except (ValueError,IndexError,UnicodeDecodeError):
            continue

# Create plot and format
fig, ax = plt.subplots(1,1)
ax.set_title('Female Enrollment in Education')
ax.set_xlabel("Year")
ax.set_ylabel("Percentage of Females Enrolled")
ax.grid('on')

# Create variables to track minimum % and maximum %
maxval = 40
minval = 60

# For each country in data, separate the year and % enrollment numbers
# into separate lists.
for n in range(0,len(data)):
    try:
        tmp = data[n][1:]
        x,y = zip(*tmp)
        
        # Check for new min or max in y values 
        if (max(y)>maxval):
            maxval = max(y)
        if (float(min(y))<minval):
            minval = float(min(y))
        
        # Look up name of each country in legend dictionary
        leg =legend.get(data[n][0])
        # Trim down long country names to first two words and add line to plot
        # using a random color
        groups = leg.split(' ')
        ax.plot(x,y, color=np.random.rand(3,), label=' '.join(groups[:words]))
    except UnicodeDecodeError:
        continue
        
# Define legend on right side of plot
lgd = ax.legend(loc='center left', bbox_to_anchor=(1, 0.5),
          fancybox=True, shadow=True)
          
# Scale y axis to 5 below lowest and 5 above highest
ax.set_ylim(float(minval)-5,float(maxval)+5)

#Size figure canvas to include all artist objects (legend)
fig.savefig('samplefigure.png', bbox_extra_artists=(lgd,), bbox_inches='tight')