# Imported Modules
from PIL import Image
from PIL import ImageDraw
from PIL import ImageFont
import matplotlib.pyplot as plt
import os.path

# Set filepath to image
directory = os.path.dirname(os.path.abspath(__file__))
filename = os.path.join(directory, "fish.jpg")

# Open as PIL Image
im = Image.open(filename)

# Crop the image it is square
cropto = min(im.size[0],im.size[1])
img = im.crop((0,0,cropto,cropto))

# Resize image to lower resolution
res = 64
img_resize = img.resize((res,res))

# Open image as Draw object and import font
draw = ImageDraw.Draw(img_resize)
font_type = ImageFont.truetype("8-BIT WONDER.TTF",16) # Font obtained from http://www.dafont.com/8bit-wonder.font

# Draw text over image. No hyphen in text, so draw rectangle for hyphen
draw.text((2, 2),"8 bit",(0,0,0),font=font_type)
draw.rectangle([18,9,23,11], fill=(0,0,0))

# Save PIL file
img_resize.save("fish_small.bmp")        

filename1 = os.path.join(directory, "fish_small.bmp")

# Create PLT image
img = plt.imread(filename1)
img_original = plt.imread(os.path.join(directory, "fish.jpg"))

# Change pixel color to 8-bit truecolor (R=3-bit, G=3-bit, B=2-bit)
for row in range(0, res):
    for column in range(0, res):
        newr = int(img[row][column][0]/32)*32
        newg = int(img[row][column][1]/32)*32
        newb = int(img[row][column][2]/64)*64
        img[row][column] = [newr, newg, newb]
        
# Create figure with two subplots
fig, ax = plt.subplots(1, 2)

# Show the image data in each subplot
ax[0].imshow(img, interpolation='none')
ax[1].imshow(img_original, interpolation='none')

# Show the figure on the screen
fig.show()